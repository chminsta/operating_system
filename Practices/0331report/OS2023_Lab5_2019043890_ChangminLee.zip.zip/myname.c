
#include <stdio.h>

int main()
{
	printf("ChangMin Lee\n");
	return 0;
}
